package com.example.tab_calculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
