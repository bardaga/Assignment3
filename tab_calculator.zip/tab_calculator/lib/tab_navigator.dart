import 'package:flutter/material.dart';
import 'package:tab_calculator/signin_screen.dart';
import 'package:tab_calculator/signup_screen.dart';
//import 'sign_in_screen.dart';
//import 'sign_up_screen.dart';
import 'calculator_screen.dart';

class TabNavigator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Simple Calculator App'),
          bottom: TabBar(
            tabs: [
              Tab(icon: Icon(Icons.login), text: 'Sign In'),
              Tab(icon: Icon(Icons.app_registration), text: 'Sign Up'),
              Tab(icon: Icon(Icons.calculate), text: 'Calculator'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            SignInScreen(),
            SignUpScreen(),
            CalculatorScreen(),
          ],
        ),
      ),
    );
  }
}
